import React from 'react'

const Shopingcart = () => {
  return (
    <div>
      
    </div>
  )
}

export default Shopingcart;
