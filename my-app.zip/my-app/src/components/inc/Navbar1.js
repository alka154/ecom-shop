import React from 'react';

import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import '../css/style.css';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';



function Navbar1({name}) {
  const topbar=[
    {call01:+9178954676, website:'pracreation.com', email:'info@gmail.com'}
  ]
  return (
    <>
    <p>{name}</p>
   <header className="header_area nav-holder sticky">
    <div className="top-bar mtopv">
  <Container>
    <Row>
		
		<Col lg={7} md={8} sm={9} xs={3} className="d-none d-sm-block">  
			
			<div className="header--info"> 
			 <ul className="nav my-md-1"> 
				
				 {

           topbar.map((topitem,c)=>
           <li className="hid" > 
					 <ul className="nav header--social" key={c}> 
           <li className="border-right">  
            <Link to="/" className="link mx-2"><i className="fas fa-envelope ico" ></i> {topitem.call01}</Link>
           </li>
          <li className="border-right "> <Link to="/" className="link mx-2"><i className="fas  fa-globe ico"></i>  {topitem.website }</Link></li>
					<li> <Link to="/" className="link mx-2"><i className="fas  fa-globe ico" ></i> {topitem.email} </Link></li>
             
            
              
						 </ul> 
				 </li>
           
           )

         }
			
			 </ul> 
		  </div>
			</Col>
			
			
		
		
		<Col lg={5} md={3} sm={3} className="d-none d-sm-block">
          <div className="logo-header mostion pt-1 float-right">
           
          <p> {name} </p>

        </div>
      </Col>

    </Row>
  </Container>
</div>
     <Navbar expand="lg" className="">
      <Container>
        <Navbar.Brand href="/Home"><img  alt='' className='img-fluid'/></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto navbar navbar-expand-lg">
            <Nav.Link href="/">Home</Nav.Link>
            <Nav.Link href="Aboutus">About Us</Nav.Link>
            <Nav.Link href="Services">Services</Nav.Link>
            <Nav.Link href="Seo">Product</Nav.Link>
            
            <Nav.Link href="Profile">Profile</Nav.Link>
            <Nav.Link href="Contact">Contact Us</Nav.Link>
            <NavDropdown title="Dropdown" id="basic-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
                Another action
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Separated link
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </header>
    </>
  );
}

export default Navbar1;

