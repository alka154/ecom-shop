import React, { useState } from 'react'

import Navbar from './components/inc/Navbar';
import Home from './components/pages/Home';

import Shop from './components/pages/Shop';
import Shopdetail from './components/pages/Shopdetail';
import Checkout from './components/pages/Checkout';
import Contact from './components/pages/Contact';
import Footer from './components/inc/Footer';
import ProductDetail from './components/pages/ProductDetail';
import SearchItem from './components/pages/SearchItem';

import Cart from './components/pages/Cart'
import Product from './components/pages/Product';


import {BrowserRouter, Route, Routes } from 'react-router-dom'
import { items } from './components/Data';


function App() {
  const [data, setData] = useState([...items])
  const [cart, setCart] = useState([])
 
 
  return (
   
    <BrowserRouter>
    
    <Navbar cart={cart} setData={setData}/>

    <Routes>
    <Route  exact  path="/"  element={<Home />}/>
    <Route path="/home"  element={<Home />}/>
        
        <Route path="/Shop" element={<Shop   title='Shop'  subtitle ='/Shop'/>} />
        <Route  path="/Shopdetail" element={<Shopdetail   title='Services'  subtitle ='/Shopdetail'/>} />
        <Route path="/Checkout" element={<Checkout   title='Seo'  subtitle ='/Checkout'/>} />
       
       
        <Route path="/Contact" element={<Contact  title='Contact Page' subtitle='/Contact'/>} />
        <Route path="/Product" element={<Product cart={cart} setCart={setCart} items={data} />} />
      <Route path="/Product/:id" element={<ProductDetail cart={cart} setCart={setCart} />} />
      <Route path="/search/:term" element={<SearchItem cart={cart} setCart={setCart} />} />
      <Route path="/Cart" element={<Cart cart={cart} setCart={setCart} />} />

    </Routes>


    <Footer/>

    </BrowserRouter>


   
  );
}

export default App;
